"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronRight, ChevronDown, AlertTriangle } from "lucide-react"
import { cn } from "@/lib/utils"

interface Initiative {
  id: string
  name: string
  status: "on-track" | "at-risk" | "delayed" | "completed" | "not-started" | "on-hold"
  progress: number
  planProgress: number
  projectCount: number
  projects?: Project[]
  alert?: string
  statusCounts?: { completed: number; delayed: number; onHold: number; notStarted: number }
}

interface Project {
  id: string
  name: string
  status: "completed" | "not-started" | "in-progress" | "delayed"
  progress: number
}

interface StrategicPillarProps {
  type: "pillar" | "enabler"
  name: string
  progress: number
  planProgress: number
  projectCount: number
  color: string
  initiatives: Initiative[]
  delay?: number
}

const statusColors = {
  "on-track": "bg-[hsl(165,60%,40%)] text-white",
  "at-risk": "bg-[hsl(35,80%,50%)] text-white",
  "delayed": "bg-[hsl(0,70%,50%)] text-white",
  "completed": "bg-[hsl(165,60%,40%)] text-white",
  "not-started": "bg-[hsl(220,10%,40%)] text-white",
  "on-hold": "bg-[hsl(250,50%,50%)] text-white",
}

const statusLabels = {
  "on-track": "On Track",
  "at-risk": "At Risk",
  "delayed": "Delayed",
  "completed": "Completed",
  "not-started": "Not Started",
  "on-hold": "On Hold",
}

export function StrategicPillar({
  type,
  name,
  progress,
  planProgress,
  projectCount,
  color,
  initiatives,
  delay = 0,
}: StrategicPillarProps) {
  const [expanded, setExpanded] = useState(false)
  const [expandedInitiative, setExpandedInitiative] = useState<string | null>(null)

  const progressColor = progress >= planProgress ? "hsl(165,60%,40%)" : 
                        progress >= planProgress * 0.7 ? "hsl(35,80%,50%)" : "hsl(0,70%,50%)"

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay, ease: "easeOut" }}
      className="bg-card rounded-xl border border-border overflow-hidden"
    >
      {/* Header */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full p-6 text-left hover:bg-secondary/30 transition-colors"
      >
        <div className="flex items-start justify-between mb-4">
          <div>
            <span className="text-xs font-semibold tracking-wider text-primary uppercase">
              {type === "pillar" ? "Strategic Pillar" : "Cross-Cutting Enabler"}
            </span>
            <h3 className="text-lg font-semibold text-foreground mt-1">{name}</h3>
          </div>
          
          <div className="text-right flex items-center gap-2">
            <div>
              <div className="text-2xl font-bold" style={{ color: progressColor }}>
                {progress}%
              </div>
              <div className="text-xs text-muted-foreground">
                plan {planProgress}% · {projectCount} projects
              </div>
            </div>
            <ChevronRight
              className={cn(
                "w-5 h-5 text-muted-foreground transition-transform duration-200",
                expanded && "rotate-90"
              )}
            />
          </div>
        </div>

        {/* Progress Bar */}
        <div className="relative h-2 bg-secondary rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.8, delay: delay + 0.3, ease: "easeOut" }}
            className="absolute left-0 top-0 h-full rounded-full"
            style={{ backgroundColor: color }}
          />
          <div
            className="absolute top-0 h-full w-0.5 bg-foreground/30"
            style={{ left: `${planProgress}%` }}
          />
        </div>
      </button>

      {/* Initiatives */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="border-t border-border"
          >
            {initiatives.map((initiative, idx) => (
              <div key={initiative.id} className="border-b border-border last:border-b-0">
                <button
                  onClick={() =>
                    setExpandedInitiative(
                      expandedInitiative === initiative.id ? null : initiative.id
                    )
                  }
                  className="w-full p-4 pl-8 text-left hover:bg-secondary/20 transition-colors"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-1 h-12 rounded-full shrink-0" style={{ backgroundColor: color }} />
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium text-foreground">{initiative.name}</span>
                        <span className={cn("px-2 py-0.5 rounded-full text-xs font-medium", statusColors[initiative.status])}>
                          {statusLabels[initiative.status]}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {initiative.projectCount} projects
                        </span>
                      </div>
                      
                      {initiative.alert && (
                        <div className="flex items-center gap-1.5 mt-1 text-[hsl(35,80%,50%)]">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span className="text-xs">{initiative.alert}</span>
                        </div>
                      )}

                      {/* Initiative Progress */}
                      <div className="mt-2 relative h-1.5 bg-secondary rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${initiative.progress}%` }}
                          transition={{ duration: 0.6, delay: 0.1 * idx }}
                          className="absolute left-0 top-0 h-full rounded-full"
                          style={{ backgroundColor: color }}
                        />
                      </div>

                      {initiative.statusCounts && (
                        <div className="flex items-center gap-3 mt-2">
                          {initiative.statusCounts.completed > 0 && (
                            <span className="text-xs px-2 py-0.5 rounded-full bg-[hsl(165,60%,40%)]/10 text-[hsl(165,60%,40%)]">
                              {initiative.statusCounts.completed} Completed
                            </span>
                          )}
                          {initiative.statusCounts.delayed > 0 && (
                            <span className="text-xs px-2 py-0.5 rounded-full bg-[hsl(0,70%,50%)]/10 text-[hsl(0,70%,50%)]">
                              {initiative.statusCounts.delayed} Delayed
                            </span>
                          )}
                          {initiative.statusCounts.onHold > 0 && (
                            <span className="text-xs px-2 py-0.5 rounded-full bg-[hsl(250,50%,50%)]/10 text-[hsl(250,50%,50%)]">
                              {initiative.statusCounts.onHold} On Hold
                            </span>
                          )}
                          {initiative.statusCounts.notStarted > 0 && (
                            <span className="text-xs px-2 py-0.5 rounded-full bg-[hsl(220,10%,50%)]/10 text-muted-foreground">
                              {initiative.statusCounts.notStarted} Not Started
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    <div className="text-right shrink-0">
                      <div className="text-lg font-semibold" style={{ color: progressColor }}>
                        {initiative.progress}%
                      </div>
                      <div className="text-xs text-muted-foreground">
                        plan {initiative.planProgress}%
                      </div>
                    </div>

                    <ChevronDown
                      className={cn(
                        "w-4 h-4 text-muted-foreground transition-transform shrink-0",
                        expandedInitiative === initiative.id && "rotate-180"
                      )}
                    />
                  </div>
                </button>

                {/* Projects */}
                <AnimatePresence>
                  {expandedInitiative === initiative.id && initiative.projects && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="bg-secondary/30"
                    >
                      {initiative.projects.map((project) => (
                        <div
                          key={project.id}
                          className="flex items-center justify-between px-8 py-3 pl-16 border-t border-border/50"
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-xs text-muted-foreground">{project.id}:</span>
                            <span className="text-sm text-foreground">{project.name}</span>
                            <span className={cn("px-2 py-0.5 rounded-full text-xs font-medium", statusColors[project.status])}>
                              {statusLabels[project.status]}
                            </span>
                          </div>
                          <span className="text-sm font-medium" style={{ color: project.progress === 100 ? "hsl(165,60%,40%)" : project.progress === 0 ? "hsl(220,10%,50%)" : color }}>
                            {project.progress}%
                          </span>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}
