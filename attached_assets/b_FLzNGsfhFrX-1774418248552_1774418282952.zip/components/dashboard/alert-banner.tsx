"use client"

import { motion } from "framer-motion"
import { AlertCircle, ChevronRight } from "lucide-react"

interface AlertBannerProps {
  count: number
  message: string
}

export function AlertBanner({ count, message }: AlertBannerProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="flex items-center justify-between p-4 rounded-xl bg-[hsl(0,70%,50%)]/10 border border-[hsl(0,70%,50%)]/20"
    >
      <div className="flex items-center gap-3">
        <AlertCircle className="w-5 h-5 text-[hsl(0,70%,50%)]" />
        <span className="text-sm font-medium text-[hsl(0,70%,50%)]">
          {count} {message}
        </span>
      </div>
      
      <button className="flex items-center gap-1 text-sm font-medium text-primary hover:underline">
        View Alerts
        <ChevronRight className="w-4 h-4" />
      </button>
    </motion.div>
  )
}
