"use client"

import { useState, useMemo } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { 
  ChevronDown, 
  ChevronRight, 
  Diamond, 
  Circle,
  Calendar,
  Filter,
  ZoomIn,
  ZoomOut
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

interface Milestone {
  id: string
  name: string
  date: Date
  type: "start" | "end" | "checkpoint" | "deadline"
}

interface GanttProject {
  id: string
  name: string
  owner: string
  startDate: Date
  endDate: Date
  progress: number
  status: "on-track" | "delayed" | "completed" | "at-risk" | "not-started" | "on-hold"
  milestones?: Milestone[]
}

interface GanttGroup {
  name: string
  color: string
  projects: GanttProject[]
}

interface GanttChartProps {
  title: string
  groups: GanttGroup[]
  startDate: Date
  endDate: Date
}

const statusConfig = {
  "on-track": { 
    bg: "bg-emerald-500/80", 
    border: "border-emerald-400",
    label: "On Track",
    textColor: "text-emerald-400"
  },
  "delayed": { 
    bg: "bg-red-500/80", 
    border: "border-red-400",
    label: "Delayed",
    textColor: "text-red-400"
  },
  "completed": { 
    bg: "bg-blue-500/80", 
    border: "border-blue-400",
    label: "Completed",
    textColor: "text-blue-400"
  },
  "at-risk": { 
    bg: "bg-amber-500/80", 
    border: "border-amber-400",
    label: "At Risk",
    textColor: "text-amber-400"
  },
  "not-started": { 
    bg: "bg-zinc-500/80", 
    border: "border-zinc-400",
    label: "Not Started",
    textColor: "text-zinc-400"
  },
  "on-hold": { 
    bg: "bg-purple-500/80", 
    border: "border-purple-400",
    label: "On Hold",
    textColor: "text-purple-400"
  },
}

const milestoneConfig = {
  "start": { icon: Circle, color: "text-emerald-400", label: "Start" },
  "end": { icon: Circle, color: "text-blue-400", label: "End" },
  "checkpoint": { icon: Diamond, color: "text-amber-400", label: "Checkpoint" },
  "deadline": { icon: Diamond, color: "text-red-400", label: "Deadline" },
}

function formatDate(date: Date): string {
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

function formatFullDate(date: Date): string {
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
}

function getMonthsBetween(start: Date, end: Date): { month: string; year: number; date: Date }[] {
  const months: { month: string; year: number; date: Date }[] = []
  const current = new Date(start.getFullYear(), start.getMonth(), 1)
  
  while (current <= end) {
    months.push({
      month: current.toLocaleDateString('en-US', { month: 'short' }),
      year: current.getFullYear(),
      date: new Date(current)
    })
    current.setMonth(current.getMonth() + 1)
  }
  
  return months
}

function getDayPosition(date: Date, start: Date, totalDays: number): number {
  const diffTime = date.getTime() - start.getTime()
  const diffDays = diffTime / (1000 * 60 * 60 * 24)
  return (diffDays / totalDays) * 100
}

function getDuration(startDate: Date, endDate: Date, chartStart: Date, totalDays: number): { left: number; width: number } {
  const start = Math.max(startDate.getTime(), chartStart.getTime())
  const end = endDate.getTime()
  
  const leftDays = (start - chartStart.getTime()) / (1000 * 60 * 60 * 24)
  const durationDays = (end - start) / (1000 * 60 * 60 * 24)
  
  return {
    left: (leftDays / totalDays) * 100,
    width: (durationDays / totalDays) * 100
  }
}

export function GanttChart({ title, groups, startDate, endDate }: GanttChartProps) {
  const [expandedGroups, setExpandedGroups] = useState<string[]>(groups.map((g) => g.name))
  const [hoveredProject, setHoveredProject] = useState<string | null>(null)
  const [zoomLevel, setZoomLevel] = useState(1)
  
  const today = new Date()
  
  const months = useMemo(() => getMonthsBetween(startDate, endDate), [startDate, endDate])
  
  const totalDays = useMemo(() => {
    return (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)
  }, [startDate, endDate])
  
  const todayPosition = useMemo(() => {
    if (today < startDate || today > endDate) return null
    return getDayPosition(today, startDate, totalDays)
  }, [today, startDate, endDate, totalDays])

  const toggleGroup = (name: string) => {
    setExpandedGroups((prev) =>
      prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name]
    )
  }

  const totalProjects = groups.reduce((sum, g) => sum + g.projects.length, 0)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="bg-card rounded-xl border border-border overflow-hidden"
    >
      {/* Header */}
      <div className="p-5 border-b border-border">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">{title}</h3>
            <p className="text-sm text-muted-foreground mt-1">
              {totalProjects} projects · {formatFullDate(startDate)} - {formatFullDate(endDate)}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="h-8 gap-1.5">
              <Filter className="w-3.5 h-3.5" />
              Filter
            </Button>
            <div className="flex items-center border border-border rounded-lg overflow-hidden">
              <button 
                onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.25))}
                className="p-1.5 hover:bg-secondary transition-colors"
              >
                <ZoomOut className="w-4 h-4 text-muted-foreground" />
              </button>
              <span className="px-2 text-xs text-muted-foreground border-x border-border">
                {Math.round(zoomLevel * 100)}%
              </span>
              <button 
                onClick={() => setZoomLevel(Math.min(2, zoomLevel + 0.25))}
                className="p-1.5 hover:bg-secondary transition-colors"
              >
                <ZoomIn className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
          </div>
        </div>
        
        {/* Legend */}
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Status:</span>
          {Object.entries(statusConfig).map(([key, config]) => (
            <div key={key} className="flex items-center gap-1.5">
              <div className={cn("w-3 h-3 rounded-sm", config.bg)} />
              <span className="text-xs text-muted-foreground">{config.label}</span>
            </div>
          ))}
          <div className="w-px h-4 bg-border mx-2" />
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Milestones:</span>
          {Object.entries(milestoneConfig).map(([key, config]) => {
            const Icon = config.icon
            return (
              <div key={key} className="flex items-center gap-1.5">
                <Icon className={cn("w-3 h-3", config.color)} />
                <span className="text-xs text-muted-foreground">{config.label}</span>
              </div>
            )
          })}
        </div>
      </div>

      {/* Chart */}
      <div className="overflow-x-auto">
        <div style={{ minWidth: `${800 * zoomLevel}px` }}>
          {/* Timeline Header */}
          <div className="flex border-b border-border sticky top-0 bg-card z-20">
            <div className="w-72 shrink-0 px-4 py-3 bg-secondary/20 border-r border-border">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Project / Task
              </span>
            </div>
            <div className="flex-1 relative">
              {/* Month headers */}
              <div className="flex">
                {months.map((monthData, idx) => {
                  const monthWidth = 100 / months.length
                  return (
                    <div
                      key={`${monthData.month}-${monthData.year}-${idx}`}
                      className="border-l border-border py-2 px-2"
                      style={{ width: `${monthWidth}%` }}
                    >
                      <div className="text-xs font-medium text-foreground">{monthData.month}</div>
                      <div className="text-[10px] text-muted-foreground">{monthData.year}</div>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>

          {/* Groups & Projects */}
          <div className="relative">
            {groups.map((group) => {
              const isExpanded = expandedGroups.includes(group.name)

              return (
                <div key={group.name}>
                  {/* Group Header */}
                  <button
                    onClick={() => toggleGroup(group.name)}
                    className="w-full flex items-center border-b border-border hover:bg-secondary/10 transition-colors"
                  >
                    <div
                      className="w-72 shrink-0 px-4 py-3 flex items-center gap-2 border-r border-border"
                      style={{ backgroundColor: `${group.color}10` }}
                    >
                      <motion.div
                        animate={{ rotate: isExpanded ? 0 : -90 }}
                        transition={{ duration: 0.2 }}
                      >
                        <ChevronDown className="w-4 h-4 text-muted-foreground" />
                      </motion.div>
                      <span className="font-semibold text-sm" style={{ color: group.color }}>
                        {group.name}
                      </span>
                      <span className="text-xs text-muted-foreground ml-1">
                        ({group.projects.length})
                      </span>
                    </div>
                    <div className="flex-1 relative h-11">
                      {/* Grid lines */}
                      <div className="absolute inset-0 flex">
                        {months.map((_, idx) => (
                          <div
                            key={idx}
                            className="border-l border-border/30 h-full"
                            style={{ width: `${100 / months.length}%` }}
                          />
                        ))}
                      </div>
                    </div>
                  </button>

                  {/* Projects */}
                  <AnimatePresence>
                    {isExpanded &&
                      group.projects.map((project, projectIdx) => {
                        const barPos = getDuration(project.startDate, project.endDate, startDate, totalDays)
                        const progressWidth = barPos.width * (project.progress / 100)
                        const isHovered = hoveredProject === project.id
                        
                        return (
                          <motion.div
                            key={project.id}
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.2, delay: 0.02 * projectIdx }}
                            className="flex items-center border-b border-border/50 hover:bg-secondary/5 transition-colors group"
                            onMouseEnter={() => setHoveredProject(project.id)}
                            onMouseLeave={() => setHoveredProject(null)}
                          >
                            {/* Project Info */}
                            <div className="w-72 shrink-0 px-4 py-3 pl-10 flex items-center gap-3 border-r border-border/50">
                              <div className={cn(
                                "w-2.5 h-2.5 rounded-full shrink-0",
                                statusConfig[project.status].bg
                              )} />
                              <div className="min-w-0 flex-1">
                                <div className="text-sm text-foreground truncate font-medium">
                                  {project.name}
                                </div>
                                <div className="text-xs text-muted-foreground flex items-center gap-2">
                                  <span>{project.owner}</span>
                                  <span className="text-muted-foreground/50">·</span>
                                  <span className={statusConfig[project.status].textColor}>
                                    {project.progress}%
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* Timeline */}
                            <div className="flex-1 relative h-16 py-2">
                              {/* Grid lines */}
                              <div className="absolute inset-0 flex">
                                {months.map((_, idx) => (
                                  <div
                                    key={idx}
                                    className="border-l border-border/20 h-full"
                                    style={{ width: `${100 / months.length}%` }}
                                  />
                                ))}
                              </div>

                              {/* Today marker */}
                              {todayPosition !== null && (
                                <div
                                  className="absolute top-0 bottom-0 w-0.5 bg-primary/60 z-10"
                                  style={{ left: `${todayPosition}%` }}
                                />
                              )}

                              {/* Project bar container */}
                              <div 
                                className="absolute top-1/2 -translate-y-1/2 h-8"
                                style={{ 
                                  left: `${barPos.left}%`, 
                                  width: `${barPos.width}%`,
                                  minWidth: '8px'
                                }}
                              >
                                {/* Background bar */}
                                <motion.div
                                  initial={{ scaleX: 0 }}
                                  animate={{ scaleX: 1 }}
                                  transition={{ duration: 0.5, delay: 0.05 * projectIdx, ease: "easeOut" }}
                                  className={cn(
                                    "absolute inset-0 rounded-md origin-left",
                                    statusConfig[project.status].bg,
                                    "opacity-30"
                                  )}
                                />
                                
                                {/* Progress bar */}
                                <motion.div
                                  initial={{ scaleX: 0 }}
                                  animate={{ scaleX: 1 }}
                                  transition={{ duration: 0.6, delay: 0.05 * projectIdx + 0.2, ease: "easeOut" }}
                                  className={cn(
                                    "absolute top-0 bottom-0 left-0 rounded-md origin-left",
                                    statusConfig[project.status].bg
                                  )}
                                  style={{ width: `${project.progress}%` }}
                                />

                                {/* Start date label */}
                                <div className={cn(
                                  "absolute -left-1 top-1/2 -translate-y-1/2 -translate-x-full pr-2 transition-opacity duration-200",
                                  isHovered ? "opacity-100" : "opacity-0"
                                )}>
                                  <span className="text-[10px] font-medium text-muted-foreground whitespace-nowrap bg-card px-1.5 py-0.5 rounded border border-border">
                                    {formatDate(project.startDate)}
                                  </span>
                                </div>

                                {/* End date label */}
                                <div className={cn(
                                  "absolute -right-1 top-1/2 -translate-y-1/2 translate-x-full pl-2 transition-opacity duration-200",
                                  isHovered ? "opacity-100" : "opacity-0"
                                )}>
                                  <span className="text-[10px] font-medium text-muted-foreground whitespace-nowrap bg-card px-1.5 py-0.5 rounded border border-border">
                                    {formatDate(project.endDate)}
                                  </span>
                                </div>

                                {/* Progress label on bar */}
                                <div className="absolute inset-0 flex items-center justify-center">
                                  <span className={cn(
                                    "text-[10px] font-bold text-white drop-shadow-sm transition-opacity",
                                    barPos.width < 5 ? "opacity-0" : "opacity-100"
                                  )}>
                                    {project.progress}%
                                  </span>
                                </div>

                                {/* Milestones */}
                                {project.milestones?.map((milestone) => {
                                  const milestonePos = getDayPosition(milestone.date, project.startDate, 
                                    (project.endDate.getTime() - project.startDate.getTime()) / (1000 * 60 * 60 * 24))
                                  const config = milestoneConfig[milestone.type]
                                  const Icon = config.icon
                                  
                                  return (
                                    <div
                                      key={milestone.id}
                                      className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 z-10 group/milestone"
                                      style={{ left: `${milestonePos}%` }}
                                    >
                                      <div className={cn(
                                        "w-4 h-4 rounded-full bg-card border-2 flex items-center justify-center",
                                        config.color.replace('text-', 'border-')
                                      )}>
                                        <Icon className={cn("w-2 h-2", config.color)} />
                                      </div>
                                      {/* Milestone tooltip */}
                                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover/milestone:opacity-100 transition-opacity pointer-events-none z-20">
                                        <div className="bg-popover border border-border rounded-lg px-2.5 py-1.5 shadow-lg whitespace-nowrap">
                                          <div className="text-xs font-medium text-foreground">{milestone.name}</div>
                                          <div className="text-[10px] text-muted-foreground">{formatFullDate(milestone.date)}</div>
                                        </div>
                                      </div>
                                    </div>
                                  )
                                })}
                              </div>

                              {/* Hover tooltip */}
                              <AnimatePresence>
                                {isHovered && (
                                  <motion.div
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: 10 }}
                                    className="absolute z-30 pointer-events-none"
                                    style={{ 
                                      left: `${barPos.left + barPos.width / 2}%`,
                                      top: '100%',
                                      transform: 'translateX(-50%)'
                                    }}
                                  >
                                    <div className="bg-popover border border-border rounded-xl px-4 py-3 shadow-xl mt-2 min-w-[200px]">
                                      <div className="text-sm font-semibold text-foreground mb-2">{project.name}</div>
                                      <div className="space-y-1.5 text-xs">
                                        <div className="flex justify-between">
                                          <span className="text-muted-foreground">Owner:</span>
                                          <span className="text-foreground">{project.owner}</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-muted-foreground">Start:</span>
                                          <span className="text-foreground">{formatFullDate(project.startDate)}</span>
                                        </div>
                                        <div className="flex justify-between">
                                          <span className="text-muted-foreground">End:</span>
                                          <span className="text-foreground">{formatFullDate(project.endDate)}</span>
                                        </div>
                                        <div className="flex justify-between items-center">
                                          <span className="text-muted-foreground">Status:</span>
                                          <span className={cn("font-medium", statusConfig[project.status].textColor)}>
                                            {statusConfig[project.status].label}
                                          </span>
                                        </div>
                                        <div className="flex justify-between items-center pt-1 border-t border-border mt-1">
                                          <span className="text-muted-foreground">Progress:</span>
                                          <div className="flex items-center gap-2">
                                            <div className="w-16 h-1.5 bg-secondary rounded-full overflow-hidden">
                                              <div 
                                                className={cn("h-full rounded-full", statusConfig[project.status].bg)}
                                                style={{ width: `${project.progress}%` }}
                                              />
                                            </div>
                                            <span className="font-semibold text-foreground">{project.progress}%</span>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </div>
                          </motion.div>
                        )
                      })}
                  </AnimatePresence>
                </div>
              )
            })}

            {/* Today line - full height */}
            {todayPosition !== null && (
              <div
                className="absolute top-0 bottom-0 z-30 pointer-events-none"
                style={{ left: `calc(288px + ${todayPosition}% * (100% - 288px) / 100)` }}
              >
                <div className="relative h-full">
                  <div className="absolute inset-y-0 w-0.5 bg-primary" />
                  <div className="absolute -top-0 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-[10px] font-medium px-1.5 py-0.5 rounded-b">
                    Today
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="px-5 py-3 border-t border-border bg-secondary/10 flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Calendar className="w-3.5 h-3.5" />
          <span>Timeline: {formatFullDate(startDate)} - {formatFullDate(endDate)}</span>
        </div>
        <div className="text-xs text-muted-foreground">
          Hover over bars for details · Click groups to expand/collapse
        </div>
      </div>
    </motion.div>
  )
}
