"use client"

import { motion } from "framer-motion"

interface HealthBarChartProps {
  title: string
  data: {
    name: string
    segments: { value: number; color: string; label?: string }[]
  }[]
}

export function HealthBarChart({ title, data }: HealthBarChartProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2, ease: "easeOut" }}
      className="bg-card rounded-xl border border-border p-6"
    >
      <h3 className="text-lg font-semibold text-foreground mb-6">{title}</h3>
      
      <div className="space-y-4">
        {data.map((item, rowIndex) => {
          const total = item.segments.reduce((sum, seg) => sum + seg.value, 0)
          
          return (
            <motion.div
              key={item.name}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4, delay: 0.1 * rowIndex }}
              className="flex items-center gap-4"
            >
              <div className="w-40 shrink-0">
                <span className="text-sm text-muted-foreground truncate block">
                  {item.name}
                </span>
              </div>
              
              <div className="flex-1 flex h-7 rounded-md overflow-hidden bg-secondary">
                {item.segments.map((segment, segIndex) => {
                  const width = (segment.value / total) * 100
                  
                  return (
                    <motion.div
                      key={segIndex}
                      initial={{ width: 0 }}
                      animate={{ width: `${width}%` }}
                      transition={{
                        duration: 0.6,
                        delay: 0.3 + 0.05 * segIndex,
                        ease: "easeOut",
                      }}
                      className="flex items-center justify-center text-xs font-medium text-white"
                      style={{ backgroundColor: segment.color }}
                    >
                      {segment.value > 0 && width > 5 && segment.value}
                    </motion.div>
                  )
                })}
              </div>
            </motion.div>
          )
        })}
      </div>

      <div className="flex items-center gap-6 mt-6 pt-4 border-t border-border">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-sm bg-[hsl(0,70%,50%)]" />
          <span className="text-xs text-muted-foreground">Critical</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-sm bg-[hsl(35,80%,50%)]" />
          <span className="text-xs text-muted-foreground">At Risk</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-sm bg-[hsl(165,60%,40%)]" />
          <span className="text-xs text-muted-foreground">On Track</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-sm bg-[hsl(220,10%,50%)]" />
          <span className="text-xs text-muted-foreground">Not Started</span>
        </div>
      </div>
    </motion.div>
  )
}
