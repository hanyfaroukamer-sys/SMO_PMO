"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  ListTodo,
  Map,
  Layers,
  Flag,
  FolderKanban,
  CheckSquare,
  TrendingUp,
  Activity,
  Wallet,
  ShoppingCart,
  Building2,
  AlertTriangle,
  FileText,
  GitBranch,
  Bell,
  History,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"

const menuItems = [
  { icon: LayoutDashboard, label: "Dashboard", active: true, badge: null },
  { icon: ListTodo, label: "My Tasks", active: false, badge: 4 },
  { icon: Map, label: "Strategy Map", active: false, badge: null },
  { icon: Layers, label: "Pillars & Enablers", active: false, badge: null },
  { icon: Flag, label: "Initiatives", active: false, badge: null },
  { icon: FolderKanban, label: "Projects", active: false, badge: null },
  { icon: CheckSquare, label: "Progress Proof", active: false, badge: null },
  { icon: TrendingUp, label: "Strategic KPIs", active: false, badge: null },
  { icon: Activity, label: "Op. KPIs", active: false, badge: null },
  { icon: Wallet, label: "Budget", active: false, badge: null },
  { icon: ShoppingCart, label: "Procurement", active: false, badge: null },
  { icon: Building2, label: "Departments", active: false, badge: null },
  { icon: AlertTriangle, label: "Risks", active: false, badge: null },
  { icon: FileText, label: "Documents", active: false, badge: null },
  { icon: GitBranch, label: "Dependencies", active: false, badge: null },
  { icon: Bell, label: "Alerts", active: false, badge: null },
  { icon: History, label: "Activity Log", active: false, badge: null },
]

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false)
  const [activeItem, setActiveItem] = useState("Dashboard")

  return (
    <aside
      className={cn(
        "relative flex flex-col h-screen bg-sidebar border-r border-sidebar-border transition-all duration-300 ease-out",
        collapsed ? "w-16" : "w-64"
      )}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 h-16 border-b border-sidebar-border">
        <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary text-primary-foreground font-semibold text-sm">
          S
        </div>
        <span
          className={cn(
            "font-semibold text-sidebar-foreground tracking-tight transition-opacity duration-200",
            collapsed ? "opacity-0" : "opacity-100"
          )}
        >
          StrategyPMO
        </span>
      </div>

      {/* Menu */}
      <nav className="flex-1 overflow-y-auto py-4 px-2">
        <ul className="space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon
            const isActive = activeItem === item.label

            return (
              <li key={item.label}>
                <button
                  onClick={() => setActiveItem(item.label)}
                  className={cn(
                    "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                    isActive
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
                  )}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span
                    className={cn(
                      "truncate transition-opacity duration-200",
                      collapsed ? "opacity-0 w-0" : "opacity-100"
                    )}
                  >
                    {item.label}
                  </span>
                  {item.badge && !collapsed && (
                    <span className="ml-auto flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full bg-primary text-primary-foreground text-xs font-medium">
                      {item.badge}
                    </span>
                  )}
                </button>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* User */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white text-xs font-medium">
            HA
          </div>
          <span
            className={cn(
              "text-sm text-sidebar-foreground font-medium truncate transition-opacity duration-200",
              collapsed ? "opacity-0" : "opacity-100"
            )}
          >
            Hany Amer
          </span>
        </div>
      </div>

      {/* Collapse Button */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 w-6 h-6 rounded-full bg-sidebar border border-sidebar-border flex items-center justify-center text-sidebar-foreground hover:bg-sidebar-accent transition-colors"
      >
        {collapsed ? (
          <ChevronRight className="w-3 h-3" />
        ) : (
          <ChevronLeft className="w-3 h-3" />
        )}
      </button>
    </aside>
  )
}
