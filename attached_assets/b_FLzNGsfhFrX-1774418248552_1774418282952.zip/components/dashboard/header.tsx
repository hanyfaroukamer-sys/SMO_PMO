"use client"

import { motion } from "framer-motion"
import { FileText, Presentation, Sparkles, Download, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"

interface HeaderProps {
  title: string
  subtitle: string
  lastUpdated: string
}

export function Header({ title, subtitle, lastUpdated }: HeaderProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex items-start justify-between"
    >
      <div>
        <h1 className="text-2xl font-bold text-foreground tracking-tight">{title}</h1>
        <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
          <span>{subtitle}</span>
          <span>·</span>
          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5" />
            <span>last updated {lastUpdated}</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Button variant="outline" size="sm" className="gap-2">
          <FileText className="w-4 h-4" />
          Export PDF
        </Button>
        <Button variant="outline" size="sm" className="gap-2">
          <Presentation className="w-4 h-4" />
          Export PPTX
        </Button>
        <Button size="sm" className="gap-2 bg-primary hover:bg-primary/90">
          <Sparkles className="w-4 h-4" />
          AI Assessment
        </Button>
      </div>
    </motion.div>
  )
}
