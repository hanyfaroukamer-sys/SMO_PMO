"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell } from "recharts"
import { cn } from "@/lib/utils"

interface BudgetChartProps {
  title: string
  subtitle: string
  allocated: { capex: number; opex: number }
  spent: { capex: number; opex: number }
}

export function BudgetChart({ title, subtitle, allocated, spent }: BudgetChartProps) {
  const [activeTab, setActiveTab] = useState<"total" | "capex" | "opex">("total")

  const data = [
    {
      name: "Allocated",
      capex: allocated.capex,
      opex: allocated.opex,
    },
    {
      name: "Spent",
      capex: spent.capex,
      opex: spent.opex,
    },
  ]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="bg-card rounded-xl border border-border p-6"
    >
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">{title}</h3>
          <p className="text-sm text-muted-foreground mt-0.5">{subtitle}</p>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex bg-secondary rounded-lg p-1">
            {(["total", "capex", "opex"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium rounded-md transition-colors uppercase",
                  activeTab === tab
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {tab}
              </button>
            ))}
          </div>
          
          <div className="text-right">
            <div className="text-sm font-medium text-primary">
              {(allocated.capex + allocated.opex).toLocaleString()}M
            </div>
            <div className="text-xs text-muted-foreground">
              CAPEX {allocated.capex}M · OPEX {allocated.opex}M
            </div>
          </div>
        </div>
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="horizontal" barGap={40}>
            <XAxis
              dataKey="name"
              axisLine={false}
              tickLine={false}
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
              tickFormatter={(value) => `${value}M`}
            />
            {(activeTab === "total" || activeTab === "capex") && (
              <Bar
                dataKey="capex"
                stackId="a"
                radius={[4, 4, 0, 0]}
                animationDuration={800}
              >
                {data.map((_, index) => (
                  <Cell key={index} fill="hsl(250, 70%, 55%)" />
                ))}
              </Bar>
            )}
            {(activeTab === "total" || activeTab === "opex") && (
              <Bar
                dataKey="opex"
                stackId="a"
                radius={[4, 4, 0, 0]}
                animationDuration={800}
              >
                {data.map((_, index) => (
                  <Cell key={index} fill="hsl(35, 70%, 55%)" />
                ))}
              </Bar>
            )}
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="flex items-center justify-center gap-6 mt-4 pt-4 border-t border-border">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-sm bg-[hsl(250,70%,55%)]" />
          <span className="text-xs text-muted-foreground">CAPEX</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-sm bg-[hsl(35,70%,55%)]" />
          <span className="text-xs text-muted-foreground">OPEX</span>
        </div>
      </div>
    </motion.div>
  )
}
