"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"

interface KpiCardProps {
  icon: LucideIcon
  value: string | number
  label: string
  subLabel?: string
  color: "blue" | "green" | "orange" | "red"
  delay?: number
}

const colorMap = {
  blue: {
    border: "border-t-[hsl(250,70%,55%)]",
    bg: "bg-[hsl(250,70%,55%)]/10",
    text: "text-[hsl(250,70%,55%)]",
  },
  green: {
    border: "border-t-[hsl(165,60%,40%)]",
    bg: "bg-[hsl(165,60%,40%)]/10",
    text: "text-[hsl(165,60%,40%)]",
  },
  orange: {
    border: "border-t-[hsl(35,80%,50%)]",
    bg: "bg-[hsl(35,80%,50%)]/10",
    text: "text-[hsl(35,80%,50%)]",
  },
  red: {
    border: "border-t-[hsl(0,70%,50%)]",
    bg: "bg-[hsl(0,70%,50%)]/10",
    text: "text-[hsl(0,70%,50%)]",
  },
}

export function KpiCard({ icon: Icon, value, label, subLabel, color, delay = 0 }: KpiCardProps) {
  const colors = colorMap[color]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay, ease: "easeOut" }}
      className={cn(
        "relative bg-card rounded-xl border border-border p-6 overflow-hidden",
        "border-t-2",
        colors.border
      )}
    >
      <div className={cn("inline-flex p-2.5 rounded-lg mb-4", colors.bg)}>
        <Icon className={cn("w-5 h-5", colors.text)} />
      </div>
      
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: delay + 0.2, ease: "easeOut" }}
        className={cn("text-4xl font-bold tracking-tight mb-1", colors.text)}
      >
        {value}
      </motion.div>
      
      <div className="text-sm font-medium text-foreground">{label}</div>
      {subLabel && (
        <div className="text-xs text-muted-foreground mt-0.5">{subLabel}</div>
      )}
    </motion.div>
  )
}
