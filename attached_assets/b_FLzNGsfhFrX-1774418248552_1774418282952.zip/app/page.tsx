"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Header } from "@/components/dashboard/header"
import { KpiCard } from "@/components/dashboard/kpi-card"
import { DonutChart } from "@/components/dashboard/donut-chart"
import { HealthBarChart } from "@/components/dashboard/health-bar-chart"
import { StrategicPillar } from "@/components/dashboard/strategic-pillar"
import { GanttChart } from "@/components/dashboard/gantt-chart"
import { BudgetChart } from "@/components/dashboard/budget-chart"
import { AlertBanner } from "@/components/dashboard/alert-banner"
import { Target, Zap, FolderOpen, LayoutGrid, Calendar, List } from "lucide-react"
import { cn } from "@/lib/utils"

// Data
const projectPhaseData = [
  { name: "Planning", value: 7, color: "hsl(250, 70%, 55%)" },
  { name: "Execution", value: 14, color: "hsl(200, 70%, 50%)" },
  { name: "Completed", value: 34, color: "hsl(165, 60%, 40%)" },
  { name: "Tendering", value: 4, color: "hsl(280, 60%, 55%)" },
  { name: "Closure", value: 0, color: "hsl(45, 80%, 50%)" },
  { name: "Not Started", value: 41, color: "hsl(220, 10%, 45%)" },
]

const projectStatusData = [
  { name: "On Track", value: 6, color: "hsl(165, 60%, 40%)" },
  { name: "Delayed", value: 17, color: "hsl(0, 70%, 50%)" },
  { name: "Not Started", value: 35, color: "hsl(220, 10%, 50%)" },
  { name: "Risk of Delay", value: 3, color: "hsl(35, 80%, 50%)" },
  { name: "Completed", value: 34, color: "hsl(165, 55%, 45%)" },
  { name: "On Hold", value: 5, color: "hsl(220, 15%, 40%)" },
]

const departmentHealthData = [
  {
    name: "Technology & Digital",
    segments: [
      { value: 1, color: "hsl(0, 70%, 50%)" },
      { value: 1, color: "hsl(35, 80%, 50%)" },
      { value: 2, color: "hsl(25, 75%, 50%)" },
      { value: 7, color: "hsl(0, 65%, 55%)" },
      { value: 8, color: "hsl(165, 60%, 40%)" },
    ],
  },
  {
    name: "Projects",
    segments: [
      { value: 1, color: "hsl(0, 70%, 50%)" },
      { value: 1, color: "hsl(35, 80%, 50%)" },
      { value: 7, color: "hsl(0, 65%, 55%)" },
      { value: 2, color: "hsl(35, 75%, 50%)" },
      { value: 7, color: "hsl(165, 60%, 40%)" },
    ],
  },
  {
    name: "Strategy & Enablement",
    segments: [
      { value: 1, color: "hsl(0, 70%, 50%)" },
      { value: 1, color: "hsl(35, 80%, 50%)" },
      { value: 5, color: "hsl(0, 65%, 55%)" },
      { value: 6, color: "hsl(165, 60%, 40%)" },
    ],
  },
  {
    name: "CX and Commercial",
    segments: [
      { value: 3, color: "hsl(35, 80%, 50%)" },
      { value: 6, color: "hsl(0, 65%, 55%)" },
      { value: 5, color: "hsl(165, 60%, 40%)" },
    ],
  },
  {
    name: "GRC and Cybersecurity",
    segments: [
      { value: 4, color: "hsl(35, 80%, 50%)" },
      { value: 3, color: "hsl(0, 65%, 55%)" },
      { value: 3, color: "hsl(165, 60%, 40%)" },
    ],
  },
  {
    name: "Shared Services",
    segments: [
      { value: 1, color: "hsl(0, 70%, 50%)" },
      { value: 2, color: "hsl(35, 80%, 50%)" },
      { value: 7, color: "hsl(165, 60%, 40%)" },
    ],
  },
  {
    name: "Operations & Maintenance",
    segments: [
      { value: 1, color: "hsl(0, 70%, 50%)" },
      { value: 1, color: "hsl(35, 80%, 50%)" },
      { value: 1, color: "hsl(25, 75%, 50%)" },
      { value: 5, color: "hsl(0, 65%, 55%)" },
      { value: 4, color: "hsl(165, 60%, 40%)" },
    ],
  },
  {
    name: "Finance",
    segments: [
      { value: 3, color: "hsl(35, 80%, 50%)" },
    ],
  },
  {
    name: "Legal",
    segments: [
      { value: 1, color: "hsl(0, 70%, 50%)" },
    ],
  },
]

const strategicPillars = [
  {
    type: "pillar" as const,
    name: "Customer Experience",
    progress: 64,
    planProgress: 52,
    projectCount: 8,
    color: "hsl(250, 70%, 55%)",
    initiatives: [
      {
        id: "i-06",
        name: "Initiative I-06: Customer Care & Satisfaction",
        status: "on-track" as const,
        progress: 57,
        planProgress: 52,
        projectCount: 5,
        statusCounts: { completed: 3, delayed: 0, onHold: 0, notStarted: 2 },
        projects: [
          { id: "P22", name: "Customer journey mapping & experience design", status: "completed" as const, progress: 100 },
          { id: "P23A", name: "Customer care centralization (Phase 1)", status: "completed" as const, progress: 100 },
          { id: "P23B", name: "Customer care centralization (Phase 2)", status: "not-started" as const, progress: 0 },
          { id: "P24", name: "Customer satisfaction survey optimization", status: "completed" as const, progress: 100 },
          { id: "P92", name: "Enhance CX & gauge customer sentiment", status: "not-started" as const, progress: 0 },
        ],
      },
      {
        id: "i-05",
        name: "Initiative I-05: Border Crossing Experience",
        status: "at-risk" as const,
        progress: 68,
        planProgress: 51,
        projectCount: 3,
        alert: "Delayed: P21: Customer journey optimization",
        statusCounts: { completed: 1, delayed: 1, onHold: 1, notStarted: 0 },
      },
    ],
  },
  {
    type: "pillar" as const,
    name: "Assets & Infrastructure",
    progress: 27,
    planProgress: 40,
    projectCount: 22,
    color: "hsl(200, 70%, 50%)",
    initiatives: [
      {
        id: "i-01",
        name: "Initiative I-01: Infrastructure Modernization",
        status: "delayed" as const,
        progress: 25,
        planProgress: 45,
        projectCount: 12,
        statusCounts: { completed: 2, delayed: 3, onHold: 2, notStarted: 5 },
      },
    ],
  },
  {
    type: "pillar" as const,
    name: "Commercialization",
    progress: 28,
    planProgress: 38,
    projectCount: 10,
    color: "hsl(15, 80%, 55%)",
    initiatives: [
      {
        id: "i-02",
        name: "Initiative I-02: Revenue Optimization",
        status: "at-risk" as const,
        progress: 30,
        planProgress: 40,
        projectCount: 6,
        statusCounts: { completed: 1, delayed: 2, onHold: 0, notStarted: 3 },
      },
    ],
  },
]

const crossCuttingEnablers = [
  {
    type: "enabler" as const,
    name: "Governance & Steering",
    progress: 61,
    planProgress: 61,
    projectCount: 17,
    color: "hsl(165, 60%, 40%)",
    initiatives: [],
  },
  {
    type: "enabler" as const,
    name: "Operational Excellence",
    progress: 17,
    planProgress: 43,
    projectCount: 9,
    color: "hsl(0, 70%, 50%)",
    initiatives: [],
  },
  {
    type: "enabler" as const,
    name: "Technology & Innovation",
    progress: 27,
    planProgress: 37,
    projectCount: 19,
    color: "hsl(35, 80%, 50%)",
    initiatives: [],
  },
  {
    type: "enabler" as const,
    name: "Capabilities Building",
    progress: 26,
    planProgress: 49,
    projectCount: 9,
    color: "hsl(165, 55%, 45%)",
    initiatives: [],
  },
]

const ganttGroups = [
  {
    name: "Customer Experience",
    color: "hsl(250, 70%, 55%)",
    projects: [
      { 
        id: "P1", 
        name: "Trusted traveler program", 
        owner: "A. Al Shrhan", 
        startDate: new Date(2026, 3, 15), 
        endDate: new Date(2026, 6, 30), 
        progress: 25,
        status: "on-track" as const,
        milestones: [
          { id: "m1", name: "Requirements Complete", date: new Date(2026, 4, 1), type: "checkpoint" as const },
          { id: "m2", name: "UAT Start", date: new Date(2026, 5, 15), type: "checkpoint" as const },
        ]
      },
      { 
        id: "P2", 
        name: "Fast lane construction & optimization", 
        owner: "O. Aldahash", 
        startDate: new Date(2025, 10, 1), 
        endDate: new Date(2026, 1, 28), 
        progress: 100,
        status: "completed" as const,
        milestones: [
          { id: "m3", name: "Project Complete", date: new Date(2026, 1, 28), type: "end" as const },
        ]
      },
      { 
        id: "P3", 
        name: "Customer journey optimization", 
        owner: "T. Mofarrij", 
        startDate: new Date(2025, 11, 15), 
        endDate: new Date(2026, 4, 30), 
        progress: 68,
        status: "delayed" as const,
        milestones: [
          { id: "m4", name: "Original Deadline", date: new Date(2026, 3, 15), type: "deadline" as const },
        ]
      },
      { 
        id: "P4", 
        name: "Customer journey mapping & design", 
        owner: "M. Fattah", 
        startDate: new Date(2025, 9, 1), 
        endDate: new Date(2025, 11, 15), 
        progress: 100,
        status: "completed" as const 
      },
      { 
        id: "P5", 
        name: "Customer care centralization (P1)", 
        owner: "B. AlTurki", 
        startDate: new Date(2025, 11, 1), 
        endDate: new Date(2026, 3, 15), 
        progress: 85,
        status: "on-track" as const,
        milestones: [
          { id: "m5", name: "Phase 1 Complete", date: new Date(2026, 3, 15), type: "end" as const },
        ]
      },
      { 
        id: "P6", 
        name: "Customer care centralization (P2)", 
        owner: "B. AlTurki", 
        startDate: new Date(2026, 3, 20), 
        endDate: new Date(2026, 7, 30), 
        progress: 0,
        status: "not-started" as const,
        milestones: [
          { id: "m6", name: "Kickoff", date: new Date(2026, 3, 20), type: "start" as const },
        ]
      },
      { 
        id: "P7", 
        name: "Customer satisfaction survey optimization", 
        owner: "S. Marzooq", 
        startDate: new Date(2025, 11, 15), 
        endDate: new Date(2026, 4, 15), 
        progress: 72,
        status: "on-track" as const 
      },
      { 
        id: "P8", 
        name: "Enhance CX & gauge customer sentiment", 
        owner: "K. Ahmed", 
        startDate: new Date(2026, 4, 1), 
        endDate: new Date(2026, 8, 30), 
        progress: 0,
        status: "not-started" as const 
      },
    ],
  },
  {
    name: "Technology & Innovation",
    color: "hsl(35, 80%, 50%)",
    projects: [
      { 
        id: "P9", 
        name: "Dynamic messaging system", 
        owner: "S. Hassan", 
        startDate: new Date(2026, 4, 1), 
        endDate: new Date(2026, 6, 15), 
        progress: 0,
        status: "not-started" as const 
      },
      { 
        id: "P10", 
        name: "TMS & real-time performance monitoring", 
        owner: "A. Alghamdi", 
        startDate: new Date(2025, 10, 15), 
        endDate: new Date(2026, 1, 28), 
        progress: 100,
        status: "completed" as const 
      },
      { 
        id: "P11", 
        name: "TMS & real-time performance (Phase 2)", 
        owner: "M. Albutery", 
        startDate: new Date(2026, 1, 1), 
        endDate: new Date(2026, 6, 30), 
        progress: 45,
        status: "on-track" as const,
        milestones: [
          { id: "m7", name: "Beta Release", date: new Date(2026, 4, 15), type: "checkpoint" as const },
          { id: "m8", name: "Production Deploy", date: new Date(2026, 6, 30), type: "deadline" as const },
        ]
      },
      { 
        id: "P12", 
        name: "Staffing deployment optimization", 
        owner: "N. Al-Rashid", 
        startDate: new Date(2026, 4, 15), 
        endDate: new Date(2026, 7, 31), 
        progress: 0,
        status: "not-started" as const 
      },
      { 
        id: "P13", 
        name: "Digital innovation hub", 
        owner: "M. Albutery", 
        startDate: new Date(2026, 4, 1), 
        endDate: new Date(2026, 6, 30), 
        progress: 15,
        status: "on-hold" as const 
      },
      { 
        id: "P14", 
        name: "Enhanced data analytics leveraging AI/ML", 
        owner: "R. Rushood", 
        startDate: new Date(2025, 11, 1), 
        endDate: new Date(2026, 4, 30), 
        progress: 35,
        status: "delayed" as const,
        milestones: [
          { id: "m9", name: "ML Model Training", date: new Date(2026, 2, 15), type: "checkpoint" as const },
          { id: "m10", name: "Original Deadline", date: new Date(2026, 3, 15), type: "deadline" as const },
        ]
      },
      { 
        id: "P15", 
        name: "Digital crossings platform", 
        owner: "Y. Mansoor", 
        startDate: new Date(2026, 4, 15), 
        endDate: new Date(2026, 7, 15), 
        progress: 0,
        status: "not-started" as const 
      },
      { 
        id: "P16", 
        name: "One-stop shop mobile app", 
        owner: "A. Shareeda", 
        startDate: new Date(2025, 11, 15), 
        endDate: new Date(2026, 3, 31), 
        progress: 92,
        status: "on-track" as const,
        milestones: [
          { id: "m11", name: "App Store Submission", date: new Date(2026, 3, 15), type: "checkpoint" as const },
        ]
      },
      { 
        id: "P17", 
        name: "JESR app revamp", 
        owner: "T. Alrammah", 
        startDate: new Date(2026, 2, 1), 
        endDate: new Date(2026, 8, 30), 
        progress: 22,
        status: "at-risk" as const,
        milestones: [
          { id: "m12", name: "Design Complete", date: new Date(2026, 3, 30), type: "checkpoint" as const },
          { id: "m13", name: "Launch", date: new Date(2026, 8, 30), type: "deadline" as const },
        ]
      },
      { 
        id: "P18", 
        name: "API integration platform and services", 
        owner: "F. Khan", 
        startDate: new Date(2026, 4, 1), 
        endDate: new Date(2026, 6, 30), 
        progress: 0,
        status: "not-started" as const 
      },
    ],
  },
  {
    name: "Assets & Infrastructure",
    color: "hsl(200, 70%, 50%)",
    projects: [
      { 
        id: "P19", 
        name: "Facility modernization program", 
        owner: "H. Abdullah", 
        startDate: new Date(2025, 8, 1), 
        endDate: new Date(2026, 5, 30), 
        progress: 78,
        status: "on-track" as const,
        milestones: [
          { id: "m14", name: "Phase 1 Complete", date: new Date(2026, 0, 31), type: "checkpoint" as const },
          { id: "m15", name: "Final Inspection", date: new Date(2026, 5, 15), type: "deadline" as const },
        ]
      },
      { 
        id: "P20", 
        name: "Security systems upgrade", 
        owner: "M. Said", 
        startDate: new Date(2025, 10, 1), 
        endDate: new Date(2026, 3, 30), 
        progress: 65,
        status: "at-risk" as const,
        milestones: [
          { id: "m16", name: "Hardware Install", date: new Date(2026, 1, 28), type: "checkpoint" as const },
        ]
      },
      { 
        id: "P21", 
        name: "Network infrastructure expansion", 
        owner: "A. Noor", 
        startDate: new Date(2026, 0, 15), 
        endDate: new Date(2026, 7, 31), 
        progress: 30,
        status: "on-track" as const 
      },
    ],
  },
]

// Gantt chart date range
const ganttStartDate = new Date(2025, 8, 1) // Sep 2025
const ganttEndDate = new Date(2026, 8, 30) // Sep 2026

type ViewType = "overview" | "pillars" | "gantt"

export default function Dashboard() {
  const [activeView, setActiveView] = useState<ViewType>("overview")

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      
      <main className="flex-1 overflow-y-auto">
        <div className="p-8 max-w-[1600px] mx-auto">
          <Header
            title="Programme Dashboard"
            subtitle="Weighted progress cascade"
            lastUpdated="Mar 25, 2026 10:03"
          />

          {/* View Tabs */}
          <div className="flex items-center gap-2 mt-6 mb-6">
            <button
              onClick={() => setActiveView("overview")}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                activeView === "overview"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              )}
            >
              <LayoutGrid className="w-4 h-4" />
              Overview
            </button>
            <button
              onClick={() => setActiveView("pillars")}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                activeView === "pillars"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              )}
            >
              <List className="w-4 h-4" />
              Strategic Pillars
            </button>
            <button
              onClick={() => setActiveView("gantt")}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                activeView === "gantt"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              )}
            >
              <Calendar className="w-4 h-4" />
              Gantt Chart
            </button>
          </div>

          <AlertBanner count={109} message="critical alerts require immediate attention." />

          <AnimatePresence mode="wait">
            {activeView === "overview" && (
              <motion.div
                key="overview"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                {/* KPI Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                  <KpiCard
                    icon={Target}
                    value="34%"
                    label="Strategy Progress"
                    subLabel="346 of 910 milestones approved"
                    color="blue"
                    delay={0}
                  />
                  <KpiCard
                    icon={Zap}
                    value="26"
                    label="Initiatives"
                    subLabel="7 on track"
                    color="green"
                    delay={0.1}
                  />
                  <KpiCard
                    icon={FolderOpen}
                    value="100"
                    label="Projects"
                    subLabel="4 need attention"
                    color="blue"
                    delay={0.2}
                  />
                </div>

                {/* Budget Chart */}
                <div className="mt-6">
                  <BudgetChart
                    title="Budget Overview"
                    subtitle="2281M SAR allocated · 31.9% utilized"
                    allocated={{ capex: 1690, opex: 591 }}
                    spent={{ capex: 539, opex: 189 }}
                  />
                </div>

                {/* Charts Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
                  <DonutChart
                    data={projectStatusData}
                    centerValue={100}
                    centerLabel="projects"
                    title="Project Status Breakdown"
                  />
                  <DonutChart
                    data={projectPhaseData}
                    centerValue={100}
                    centerLabel="projects"
                    title="Project Phase Distribution"
                  />
                </div>

                {/* Department Health */}
                <div className="mt-6">
                  <HealthBarChart
                    title="Department Health Overview"
                    data={departmentHealthData}
                  />
                </div>
              </motion.div>
            )}

            {activeView === "pillars" && (
              <motion.div
                key="pillars"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                {/* Strategic Pillars */}
                <div className="mt-6">
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-1 h-5 rounded-full bg-primary" />
                    <h2 className="text-lg font-semibold text-foreground">Strategic Pillars</h2>
                  </div>
                  <div className="space-y-4">
                    {strategicPillars.map((pillar, idx) => (
                      <StrategicPillar key={pillar.name} {...pillar} delay={0.1 * idx} />
                    ))}
                  </div>
                </div>

                {/* Cross-Cutting Enablers */}
                <div className="mt-8">
                  <div className="flex items-center gap-2 mb-4">
                    <Zap className="w-5 h-5 text-primary" />
                    <h2 className="text-lg font-semibold text-foreground">Cross-Cutting Enablers</h2>
                  </div>
                  <div className="space-y-4">
                    {crossCuttingEnablers.map((enabler, idx) => (
                      <StrategicPillar key={enabler.name} {...enabler} delay={0.1 * idx} />
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {activeView === "gantt" && (
              <motion.div
                key="gantt"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="mt-6"
              >
                <GanttChart
                  title="Projects & Milestones"
                  groups={ganttGroups}
                  startDate={ganttStartDate}
                  endDate={ganttEndDate}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  )
}
